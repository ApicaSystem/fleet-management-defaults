#!/bin/sh

apt-get remove --purge -y fluent-bit
