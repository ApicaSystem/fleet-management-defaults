#!/bin/sh

rm -rf /opt/fluent-bit
