#!/bin/sh

rm -rf /opt/prometheus
