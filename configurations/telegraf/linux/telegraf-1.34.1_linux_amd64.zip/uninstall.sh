#!/bin/sh

rm -rf /opt/telegraf
